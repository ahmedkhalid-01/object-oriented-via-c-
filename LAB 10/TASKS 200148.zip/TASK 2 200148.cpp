#include <iostream>
#include <exception>
using namespace std;

int main(){

    int a, b, c;
    cout << "Enter the value of a: ";
    cin>>a;
    cout << "Enter the value of b: ";
    cin>>b;

    try {
        if (a != 0){
        	throw c;
			         
        } 
		else{
			c = a / b;
            cout << "Result is: " << c;
        }
    } 
	catch (int c){
        cout << "\nException caught.\nAs we have b = "<<b<<".";
    }
    return 0;
}
