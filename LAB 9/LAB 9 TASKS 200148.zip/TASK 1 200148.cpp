#include <iostream>
#include <list>
using namespace std;

template<class T>
class Disp
{
    public:
    void display(list<T> &L)
    {
        typename list<T> :: iterator i;
        for(i=L.begin();i!=L.end();i++)
            cout<<*i<<endl;
    }
};

int main() {
    Disp<int> d;
    list<int> L;
    L.push_back(1);
    L.push_back(2);
    L.push_back(3);
    L.push_back(4);
    d.display(L);

    return 0;
}
